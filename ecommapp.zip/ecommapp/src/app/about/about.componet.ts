import { Component } from '@angular/core';

@Component({
  selector: 'app-about',
  template: `
    <div>
      <h2>About Us</h2>
      <p>Explanation of folder structure, challenges faced, and project startup steps.</p>
    </div>
  `,
  styleUrls: ['./about.component.css']
})
export class AboutComponent {}