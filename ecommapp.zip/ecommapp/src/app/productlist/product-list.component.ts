// product-list.component.ts
import { Component, OnInit } from '@angular/core';
import { ProductService } from './product.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  searchTerm: string = '';
  
  products: any[] = [];
  searchProducts() {
    
  }

  constructor(private productService: ProductService) {}

  ngOnInit(): void {
    const accessToken = '';
    this.productService.getProductList(accessToken).subscribe(
      (productList: any) => {
        this.products = productList;
      },
      (error: any) => {
        console.error('Error fetching product list', error);
      }
    );
  }
}
