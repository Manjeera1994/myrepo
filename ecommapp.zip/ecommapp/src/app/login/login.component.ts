import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from './auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

  export class LoginComponent {
    loginForm: FormGroup;
  
    constructor(private authService: AuthService, private fb: FormBuilder,private router: Router) {
      this.loginForm = this.fb.group({
        email: ['', [Validators.required, Validators.email]],
        password: ['', [Validators.required, Validators.pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/)]]
      });
    }
  
    login(): void {
      if (this.loginForm.valid) {
        const email = this.loginForm.get('email').value;
        const password = this.loginForm.get('password').value;

        this.authService.login(email, password).subscribe(
          (response) => {
            //console.log(response);
            if(response.access_token)
            {
              this.router.navigate(['products']);
            }
          },
          (error) => {
            console.error('Login failed', error);
          }
        );
      }
    }
  }

