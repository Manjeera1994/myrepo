// auth.service.ts
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, Observer } from 'rxjs';
import { map } from 'rxjs/operators';
import * as CryptoJS from 'crypto-js';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private loggedIn = false;
  private accessToken: string | null = null;
  isAuthenticated() {
    throw new Error('Method not implemented.');
  }
  
  private loginApiUrl = 'https://apiv2stg.promilo.com/user/oauth/token';

  constructor(private http: HttpClient) {}

  login(email: string, password: string): Observable<any> {
    const formData = new FormData();
    formData.append('username', email);
    formData.append('password', CryptoJS.SHA256(password).toString(CryptoJS.enc.Hex));
    formData.append('grant_type', 'password');
    
       
    const headers = new HttpHeaders({
      'Authorization': 'Basic UHJvbWlsbzpxNCE1NkBaeSN4MiRHQg=='
    });

    return this.http.post(this.loginApiUrl, formData, { headers });
      
  }
}
